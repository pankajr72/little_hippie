<div class="">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="{{ URL::asset('images/logo.png')}}" width="125px" alt="">
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="/">Home</a></li>
                        <li><a href="/products">Products</a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Contact</a></li>
                        <li><a href="/dashboard">Account</a></li>
                    </ul>
                </nav>
                <a href="/cart"><img src="{{ URL::asset('images/cart.png')}}" width="30px" height="30px" alt=""></a>
                <img src="{{ URL::asset('images/menu.png')}}" class="menu-icon" onclick="menutoggle()">
            </div>
            <!-- Navbar ends here -->
        </div>
    </div>