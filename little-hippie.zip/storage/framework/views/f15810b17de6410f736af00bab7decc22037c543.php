

<?php $__env->startSection('title','Products'); ?>

<?php $__env->startSection('content'); ?>
    <br>
    <a href="<?php echo e(route('productscategory.create')); ?>" class="btn btn-primary btn-block">Add Product Category</a><br>
    <table class="table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Product Category</th>
                <th>Operations</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($productCategory->id); ?></td>
                    <td><?php echo e($productCategory->category); ?></td>
                    <td>
                        <a href="<?php echo e(route('productscategory.edit',$productCategory->id)); ?>" class="btn btn-light">Edit</a>
                        <form style="display:inline-block;" action="<?php echo e(route('productscategory.destroy',$productCategory->id)); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <?php echo method_field('DELETE'); ?>

                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/product_category/index.blade.php ENDPATH**/ ?>