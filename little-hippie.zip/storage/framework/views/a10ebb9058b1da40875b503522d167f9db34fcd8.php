

<?php $__env->startSection('title','Add New Product'); ?>

<?php $__env->startSection('content'); ?>
    
<br><br>
    <div class="card">
        <div class="card-header">
            Add New Product
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('products.store')); ?>" method="post">
            <?php echo csrf_field(); ?> 

                <div class="form-group">
                    <label for="">Category :</label>
                    <select name="category_id" class="form-control">
                        <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($productCategory->id); ?>"><?php echo e($productCategory->category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="">Product Name :</label>
                    <input type="text" name="p_name" class="form-control">
                </div>

                <div class="form-group">
                    <label for="">Product Description :</label>
                    <textarea name="p_desc" class="form-control"></textarea>
                </div>

                <div class="form-group">
                    <label for="">Product Price :</label>
                    <input type="number" name="p_price" class="form-control">
                </div>

                <input type="submit" value="Add" class="btn btn-success btn-block">

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/products/create.blade.php ENDPATH**/ ?>