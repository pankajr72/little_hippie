<?php $__env->startSection('title','Sign In'); ?>


<?php $__env->startSection('content'); ?>

    <!-- Account Page -->

    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="account-page">
        <div class="container">
            <div class="row">
                <div class="col-2">
                    <img src="images/hero.jpg" width="100%">
                </div>

                <div class="col-2">
                    <div class="form-container">
                        <div class="form-btn">
                            <span onclick="login()">Login</span>
                            <span onclick="register()">Register</span>
                            <hr id="indicator">
                        </div>

                        <form action="<?php echo e(route('login')); ?>" id="loginForm" method="post">
                        <?php echo csrf_field(); ?>
                            <input type="email" name="email" placeholder="Email">
                            <input type="password" name="password" placeholder="Password" id="">
                            <button type="submit" class="btn">Login</button>
                            <a href="" style="font-size: 13px">Forgot password</a>
                        </form>

                        <form action="" id="regForm" method="post">
                        <?php echo csrf_field(); ?>
                            <input type="text" placeholder="Username">
                            <input type="email" placeholder="Email">
                            <input type="password" name="" placeholder="Password" id="">
                            <button type="submit" class="btn">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
      const loginForm = document.getElementById("loginForm");
      const regForm = document.getElementById("regForm");
      const indicator = document.getElementById("indicator");

      function register()
      {
          regForm.style.transform = "translateX(0px)";
          loginForm.style.transform = "translateX(0px)";
          indicator.style.transform = "translateX(105px)";
      }

      function login()
      {
          regForm.style.transform = "translateX(300px)";
          loginForm.style.transform = "translateX(300px)";
          indicator.style.transform = "translateX(5px)";
      }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.templ', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\55- little hippie\little-hippie\resources\views/auth/login.blade.php ENDPATH**/ ?>