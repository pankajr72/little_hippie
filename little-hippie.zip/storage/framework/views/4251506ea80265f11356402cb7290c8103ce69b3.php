

<?php $__env->startSection('title','Products Images'); ?>

<?php $__env->startSection('content'); ?>
    <br>
    <a href="<?php echo e(route('productsimages.create')); ?>" class="btn btn-primary btn-block">Add Product Image</a><br>
    <table class="table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Product Name</th>
                <th>Image Title</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($productImage->id); ?></td>
                    <td><?php echo e($productImage->product->p_name); ?></td>
                    <td><?php echo e($productImage->img_title); ?></td>
                    <td><img src="<?php echo e($productImage->img); ?>" width="100px"></td>
                    <td>
                        <a href="<?php echo e(route('productsimages.edit',$productImage->id)); ?>" class="btn btn-light">Edit</a>
                            <form style="display:inline-block;" action="<?php echo e(route('productsimages.destroy',$productImage->id)); ?>" method="post">
                            <?php echo csrf_field(); ?> 
                            <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/product_images/index.blade.php ENDPATH**/ ?>