<div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="<?php echo e(URL::asset('images/logo.png')); ?>" width="125px" alt="">
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="/">Home</a></li>
                        <li><a href="/products">Products</a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Contact</a></li>
                        <li><a href="/dashboard">Account</a></li>
                    </ul>
                </nav>
                <a href="/cart"><img src="<?php echo e(URL::asset('images/cart.png')); ?>" width="30px" height="30px" alt=""></a>
                <img src="<?php echo e(URL::asset('images/menu.png')); ?>" class="menu-icon" onclick="menutoggle()">
            </div>
            <!-- Navbar ends here -->
                    <img src="<?php echo e(URL::asset('images/hero.png')); ?>">
            </div>
        </div>
    </div><?php /**PATH F:\Web Development\Laravel Projects\55- little hippie\little-hippie\resources\views/layouts/headerhero.blade.php ENDPATH**/ ?>