

<?php $__env->startSection('title','Products'); ?>

<?php $__env->startSection('content'); ?>
    <br>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary btn-block">Add Product</a><br>
    <table class="table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Image</th>
                <th>Product Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Category</th>
                <th>Operations</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><img src="<?php echo e($product->productImages->first() ? $product->productImages->first()->img : ''); ?>" width="80px"></td>
                    <td><?php echo e($product->p_name); ?></td>
                    <td><?php echo e($product->p_desc); ?></td>
                    <td><?php echo e($product->p_price); ?></td>
                    <td><?php echo e($product->productCategory->category); ?></td>
                    <td>
                        <a href="<?php echo e(route('products.edit',$product->id)); ?>" class="btn btn-light">Edit</a>
                            <form style="display:inline-block;" action="<?php echo e(route('products.destroy',$product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?> 
                            <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/products/index.blade.php ENDPATH**/ ?>