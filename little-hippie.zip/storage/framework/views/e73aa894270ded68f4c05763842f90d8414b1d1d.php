

<?php $__env->startSection('title','Add New Product'); ?>

<?php $__env->startSection('content'); ?>
    
<br><br>
    <div class="card">
        <div class="card-header">
            Add New Product Category
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('productscategory.store')); ?>" method="post">
            <?php echo csrf_field(); ?> 

                <div class="form-group">
                    <label for="">Product Category :</label>
                    <input type="text" name="category" class="form-control">
                </div>
                <br>
                <input type="submit" value="Add" class="btn btn-success btn-block">
                

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/product_category/create.blade.php ENDPATH**/ ?>