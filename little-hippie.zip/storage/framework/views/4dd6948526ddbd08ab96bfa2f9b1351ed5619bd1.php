

<?php $__env->startSection('title', "RedStore"); ?>



<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.headerhero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Featured Products -->

<div class="small-container">
    <h2 class="title">Featured Products</h2>

    <div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <img src="<?php echo e($product->productImages->first()->img); ?>" alt="">
            <a href="<?php echo e('/product/'. $product->slug); ?>"><h4><?php echo e($product->p_name); ?></h4></a>
            <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                    class="fa fa-star"></i><i class="fa fa-star-o"></i></div>

            <p>Rs. <?php echo e($product->p_price); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    

<!-- Testimonial -->
<div class="testimonial">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ut nisl et odio dictum
                    viverra. Integer ornare lectus quis lorem congue, quis commodo ligula fringilla. Nullam a elit
                    id felis convallis rutrum ut ac turpis. In
                    porta eleifend lectus eget rutrum.</p>

                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>

                <img src="images/user-1.png" alt="">
                <h3>Sean Parker</h3>
            </div>
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ut nisl et odio dictum
                    viverra. Integer ornare lectus quis lorem congue, quis commodo ligula fringilla. Nullam a elit
                    id felis convallis rutrum ut ac turpis. In
                    porta eleifend lectus eget rutrum.</p>

                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>

                <img src="images/user-2.png" alt="">
                <h3>Mike Smith</h3>
            </div>
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ut nisl et odio dictum
                    viverra. Integer ornare lectus quis lorem congue, quis commodo ligula fringilla. Nullam a elit
                    id felis convallis rutrum ut ac turpis. In
                    porta eleifend lectus eget rutrum.</p>

                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>

                <img src="images/user-3.png" alt="">
                <h3>Mabel Joe</h3>
            </div>
        </div>
    </div>
</div>

<!-- Brands -->
<div class="brands">
    <div class="small-container">
        <div class="row">
            <div class="col-5">
                <img src="images/logo-pampers.png" alt="">
            </div>
            <div class="col-5">
                <img src="images/logo-comfort.png" alt="">
            </div>
            <div class="col-5">
                <img src="images/logo-chicco.png" alt="">
            </div>
            <div class="col-5">
                <img src="images/logo-johnson.png" alt="">
            </div>
            <div class="col-5">
                <img src="images/logo-metro.png" style="width: 100px !important" alt="">
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.templ', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\55- little hippie\little-hippie\resources\views/index.blade.php ENDPATH**/ ?>