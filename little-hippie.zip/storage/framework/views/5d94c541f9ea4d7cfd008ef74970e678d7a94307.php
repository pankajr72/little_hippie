

<?php $__env->startSection('title', "All Products | RedStore"); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="small-container">
    <div class="row row-2">
        <h2>All Products</h2>
        <select name="" id="">
            <option value="">Default Sorting</option>
            <option value="">Sort By Price</option>
            <option value="">Sort By Popularity</option>
            <option value="">Sort By Rating</option>
            <option value="">Sort By Rating</option>
            <option value="">Sort By Sale</option>
        </select>
    </div>
    <div class="row float-md-left">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <img src="<?php echo e($product->productImages->first()->img); ?>" alt="">
            <a href="<?php echo e('/product/'. $product->slug); ?>"><h4><?php echo e($product->p_name); ?></h4></a>
            <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                    class="fa fa-star"></i><i class="fa fa-star-o"></i></div>

            <p>Rs. <?php echo e($product->p_price); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="page-btn">
        <span>1</span>
        <span>2</span>
        <span>3</span>
        <span>4</span>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.templ', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/products.blade.php ENDPATH**/ ?>