

<?php $__env->startSection('title','Add New Product Image'); ?>

<?php $__env->startSection('content'); ?>
    
<br><br>
    <div class="card">
        <div class="card-header">
            Add New Product Image
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('productsimages.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> 

                
                <div class="form-group">
                    <label for="">Select Product</label>
                    <select name="product_id" class="form-control">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>"><?php echo e($product->p_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="">Image :</label>
                    <input type="file" name="img" class="form-control">
                </div>

                <div class="form-group">
                    <label for="">Image Title</label>
                    <input type="text" name="img_title" class="form-control">
                </div>

                <input type="submit" value="Add" class="btn btn-success btn-block">

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/product_images/create.blade.php ENDPATH**/ ?>