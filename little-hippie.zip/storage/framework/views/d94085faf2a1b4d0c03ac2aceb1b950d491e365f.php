

<?php $__env->startSection('title','Cart'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="small-container cart-page">

        <table>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
            <?php 
                    $total = 0;
                    $subtotal = 0;
            ?>
            <?php if(session('cart')): ?>

            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td>
                    <div class="cart-info">
                        <img src="<?php echo e($product['img']); ?>">
                        <div>
                            <p><?php echo e($product['p_name']); ?></p>
                            <small>Price: Rs. <?php echo e($product['p_price']); ?></small><br>
                            <small>Size: <?php echo e($product['size']); ?></small><br>
                            <a href="<?php echo e(route('removefromcart',$id)); ?>">Remove</a>
                        </div>
                    </div>
                </td>
                <td><?php echo e($product['qty']); ?></td>
                <td>Rs. <?php echo e($product['p_price'] * $product['qty']); ?></td>
            </tr>

            <?php 
                $subtotal += $product['p_price'] * $product['qty'];
            ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>

        <div class="total-price">
            <table>
                <tr>
                    <td>Subtotal</td>
                    <td>Rs. <?php echo $subtotal ?></td>
                </tr>
                <tr>
                    <td>Delivery Charges</td>
                    <td>Rs. 40</td>
                </tr>
                <tr>
                    <td>Total</td>
                    <td>Rs. <?php $total = $subtotal+40;
                            echo $total; ?></td>
                </tr>
                <tr>
                    <td colspan=2>
                        <form action="<?php echo e(route('pay')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <input type="hidden" name='amount' value="<?php echo e($total); ?>">
                            <button type="submit" class="btn bpay">Proceed To Pay</button>
                        </form>
                    </td>
                </tr>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.templ', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\55- little hippie\little-hippie\resources\views/cart.blade.php ENDPATH**/ ?>