

<?php $__env->startSection('title',"$product->p_name"); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Single Product -->

    <div class="small-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="<?php echo e($product->productImages->first()->img); ?>" id="product-img">

                <div class="small-img-row">
                <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="small-img-col">
                        <img src="<?php echo e($productImage->img); ?>" width="100%" class="small-img">                       
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-2">
                <p>Home / <?php echo e($product->productCategory->category); ?></p>
                <h1><?php echo e($product->p_name); ?></h1>
                <h4>Rs. <?php echo e($product->p_price); ?></h4>
                <form action="<?php echo e(route('addtocart',$product->id)); ?>" method="post" style="display:inline-block; margin:0;padding:0">          
                <?php echo csrf_field(); ?>          
                    <select name="size" id="">
                        <option value="">Select Size</option>
                        <option value="XXL">XXL</option>
                        <option value="XL">XL</option>
                        <option value="L">L</option>
                        <option value="M">M</option>
                        <option value="S">S</option>
                    </select>
                    <input type="number" name="qty" value="1" class="">
                    <button type="submit" class="btn badd">Add To Cart</button>
                </form>
                <br><br>
                <h3>Product Details <i class="fa fa-indent"></i> </h3><br>
                <p>
                <?php echo e($product->p_desc); ?>

                </p>
            </div>
        </div>
    </div>

    <div class="small-container">
        <div class="row row-2">
            <h2>Related Products</h2>
            <p>View more</p>
        </div>
    </div>

    <div class="small-container">
        
        <div class="row">            
            <div class="col-4">
                <img src="<?php echo e(URL::asset('images/product-10.jpg')); ?>" alt="">
                <h4>Sports Shoes</h4>
                <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i></div>

                <p>$99.99</p>
            </div>
            <div class="col-4">
                <img src="<?php echo e(URL::asset('images/product-11.jpg')); ?>" alt="">
                <h4>Casual Shoes</h4>
                <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i></div>

                <p>$19.99</p>
            </div>
            <div class="col-4">
                <img src="<?php echo e(URL::asset('images/product-12.jpg')); ?>" alt="">
                <h4>Track Pants</h4>
                <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i></div>

                <p>$79.99</p>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
        var productImg = document.getElementById("product-img");
        var smallImg = document.getElementsByClassName("small-img");

        smallImg[0].onclick = function()
        {
            productImg.src = smallImg[0].src;
        }
        smallImg[1].onclick = function()
        {
            productImg.src = smallImg[1].src;
        }
        smallImg[2].onclick = function()
        {
            productImg.src = smallImg[2].src;
        }
        smallImg[3].onclick = function()
        {
            productImg.src = smallImg[3].src;
        }

    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.templ', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/product-details.blade.php ENDPATH**/ ?>