

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\55- little hippie\little-hippie\resources\views/dashboard.blade.php ENDPATH**/ ?>