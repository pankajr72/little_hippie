

<?php $__env->startSection('title','Edit Product'); ?>

<?php $__env->startSection('content'); ?>
    
<br><br>
    <div class="card">
        <div class="card-header">
            Edit Product
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('products.update',$product->id)); ?>" method="post">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="">Category :</label>
                    <select name="category_id" class="form-control">
                        <option value="<?php echo e($product->category_id); ?>"><?php echo e($product->productCategory->category); ?></option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="">Product Name :</label>
                    <input type="text" value="<?php echo e($product->p_name); ?>" name="p_name" class="form-control">
                </div>

                <div class="form-group">
                    <label for="">Product Description :</label>
                    <textarea name="p_desc" class="form-control"><?php echo e($product->p_desc); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="">Product Price :</label>
                    <input type="number" value="<?php echo e($product->p_price); ?>" name="p_price" class="form-control">
                </div>

                <input type="submit" value="Update" class="btn btn-success btn-block">

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web Development\Laravel Projects\53 - Laravel E-Commerce Practice 6\ecommerce-practice-6\resources\views/products/edit.blade.php ENDPATH**/ ?>